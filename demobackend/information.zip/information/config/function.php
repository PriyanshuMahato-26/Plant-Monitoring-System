<?php

class Database {
    public $conn;
    private $host = 'localhost';
    private $username='root';
    private $password='';
    private $db='test';

    public function getConnection(){
        $this->conn=null;
        try{
            $this->conn=new PDO("mysql:host".$this->host.";dbname=".$this->db,$this->username,$this->password);
        }catch(PDOException $e){
            return "Connection Failed: ".$e->getMessage();
        }
        return $this->conn;
    }
    
    public function information($city){
        $sql='use test';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $sql='select * from data where city = "'.$city.'"';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $a=0;
        $data=array();
        while($result = $stmt ->fetch(PDO::FETCH_ASSOC)){
            $a=$a+1;
            $data[]=$result;
        };
        if($a > 0)
        {
            $response['status']="The information of the city is as follows";
            $response['error']=false;
            $response['data']=$data;
        }
        else{
            $response['status']="Information of the city not found";
            $response['error']=true;
        }
        return $response;
    }
}
?>