<?php

include_once '../config/function.php';
$pdo = new database();
$pdo -> getConnection();
$city=isset($_POST['city'])? $_POST['city'] : '';
echo json_encode($pdo->information($city))
?>